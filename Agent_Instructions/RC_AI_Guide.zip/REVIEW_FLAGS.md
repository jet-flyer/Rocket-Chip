# Review Flags

Cross-agent observations and questions. See `CROSS_AGENT_REVIEW.md` for protocol.

**Last reviewed by Nathan**: *[DATE]*

---

## Open Flags

*No open flags.*

<!-- Template for new flags:

### [DATE] - [AGENT NAME]
**File**: `path/to/file`  
**Lines**: (if applicable)  
**Observation**: [What you noticed]  
**Why it seems odd**: [Your reasoning]  
**Possible explanations**: [What might justify this]  
**Severity**: Low / Medium / High  
**Recommendation**: [Ask Nathan / Defer / Needs discussion]

---

-->

---

## Resolved

*No resolved flags yet.*

<!-- Move resolved flags here with resolution notes:

### [DATE] - [AGENT] (Resolved [DATE])
**File**: `path/to/file`  
**Observation**: [Original observation]  
**Resolution**: [Decision and reasoning]

---

-->
